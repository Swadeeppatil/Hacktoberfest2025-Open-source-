import React, { useState, useEffect, useRef, memo } from 'react';
import { createRoot } from 'react-dom/client';
import { GoogleGenAI, Type, Chat } from "@google/genai";

// --- Standalone, Memoized Components ---

const AccordionItem = memo(({ id, title, children, openAccordion, toggleAccordion }: { id: string; title: string; children: React.ReactNode; openAccordion: string | null; toggleAccordion: (id: string) => void; }) => (
    <div className="accordion-item">
        <div className="accordion-header" onClick={() => toggleAccordion(id)} role="button" tabIndex={0} aria-expanded={openAccordion === id}>
            <span>{title}</span>
            <span>{openAccordion === id ? '−' : '+'}</span>
        </div>
        {openAccordion === id && <div className="accordion-content">{children}</div>}
    </div>
));

const SavedTripsModal = memo(({ savedTrips, loadTrip, handleDownloadSavedTrip, deleteTrip, setShowSavedTrips }: { savedTrips: any[], loadTrip: (trip: any) => void, handleDownloadSavedTrip: (trip: any) => void, deleteTrip: (id: number) => void, setShowSavedTrips: (show: boolean) => void }) => (
    <div className="modal-overlay" onClick={() => setShowSavedTrips(false)}>
        <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
                <h2>Saved Trips</h2>
                <button onClick={() => setShowSavedTrips(false)} className="modal-close-btn" aria-label="Close saved trips">&times;</button>
            </div>
            {savedTrips.length > 0 ? (
                <ul className="saved-trips-list">
                    {savedTrips.map(trip => (
                        <li key={trip.id} className="saved-trip-item">
                            <div><strong>{trip.destination}</strong><br /><small>Saved on: {new Date(trip.savedAt).toLocaleDateString()}</small></div>
                            <div className="saved-trip-actions">
                                <button onClick={() => loadTrip(trip)} className="btn-sm btn-primary">Load</button>
                                <button onClick={() => handleDownloadSavedTrip(trip)} className="btn-sm btn-download-sm">Download</button>
                                <button onClick={() => deleteTrip(trip.id)} className="btn-sm btn-danger">Delete</button>
                            </div>
                        </li>
                    ))}
                </ul>
            ) : (<p>You have no saved trips yet.</p>)}
        </div>
    </div>
));

const AuthModal = memo(({ authMode, setShowAuthModal, authForm, handleAuthChange, authError, handleLogin, handleSignup }: { authMode: 'login' | 'signup', setShowAuthModal: (show: boolean) => void, authForm: any, handleAuthChange: (e: React.ChangeEvent<HTMLInputElement>) => void, authError: string, handleLogin: () => void, handleSignup: () => void }) => (
    <div className="modal-overlay" onClick={() => setShowAuthModal(false)}>
        <div className="modal-content auth-modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
                <h2>{authMode === 'login' ? 'Login' : 'Sign Up'}</h2>
                <button onClick={() => setShowAuthModal(false)} className="modal-close-btn" aria-label="Close auth modal">&times;</button>
            </div>
            <div className="form-group"><label htmlFor="username">Username</label><input type="text" id="username" name="username" value={authForm.username} onChange={handleAuthChange} /></div>
            <div className="form-group"><label htmlFor="password">Password</label><input type="password" id="password" name="password" value={authForm.password} onChange={handleAuthChange} /></div>
            {authError && <div className="error-message small-error">{authError}</div>}
            {authMode === 'login' ? (<button onClick={handleLogin}>Login</button>) : (<button onClick={handleSignup}>Sign Up</button>)}
        </div>
    </div>
));

const ProfileModal = memo(({ setShowProfileModal, currentUserData, profilePicInput, setProfilePicInput, handleProfileSave }: { setShowProfileModal: (show: boolean) => void, currentUserData: any, profilePicInput: string, setProfilePicInput: (val: string) => void, handleProfileSave: () => void }) => (
    <div className="modal-overlay" onClick={() => setShowProfileModal(false)}>
        <div className="modal-content profile-modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
                <h2>Your Profile</h2>
                <button onClick={() => setShowProfileModal(false)} className="modal-close-btn" aria-label="Close profile modal">&times;</button>
            </div>
            <div className="form-group">
                <label>Username</label>
                <input type="text" value={currentUserData?.username || ''} disabled />
            </div>
            <div className="form-group">
                <label htmlFor="profilePicUrl">Profile Picture URL</label>
                <input type="text" id="profilePicUrl" value={profilePicInput} onChange={(e) => setProfilePicInput(e.target.value)} placeholder="https://example.com/image.png"/>
            </div>
            <button onClick={handleProfileSave}>Save Profile</button>
        </div>
    </div>
));

const ImageModal = memo(({ currentImageInModal, setIsImageModalOpen }: { currentImageInModal: string, setIsImageModalOpen: (open: boolean) => void }) => (
    <div className="modal-overlay image-modal-overlay" onClick={() => setIsImageModalOpen(false)}>
        <div className="modal-content image-modal-content" onClick={(e) => e.stopPropagation()}>
            <button onClick={() => setIsImageModalOpen(false)} className="modal-close-btn" aria-label="Close image view">&times;</button>
            <img src={currentImageInModal} alt="Full size view of attraction" className="full-size-image" />
        </div>
    </div>
));

// Fix: Corrected the type for the setIsChatOpen prop to allow functional updates.
const ChatAssistant = memo(({ isChatOpen, setIsChatOpen, chatHistory, isChatLoading, chatInput, setChatInput, handleSendMessage }: { isChatOpen: boolean, setIsChatOpen: React.Dispatch<React.SetStateAction<boolean>>, chatHistory: any[], isChatLoading: boolean, chatInput: string, setChatInput: (val: string) => void, handleSendMessage: (e: React.FormEvent) => void }) => {
    const chatHistoryRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (chatHistoryRef.current) {
            chatHistoryRef.current.scrollTop = chatHistoryRef.current.scrollHeight;
        }
    }, [chatHistory]);

    return (
        <>
            <button className="chat-fab" onClick={() => setIsChatOpen(prev => !prev)} aria-label="Toggle Tourist Guide Chat">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>
            </button>
            {isChatOpen && (
                <div className="chat-window">
                    <div className="chat-header">
                        <h3>AI Tourist Guide</h3>
                        <button onClick={() => setIsChatOpen(false)}>&times;</button>
                    </div>
                    <div className="chat-history" ref={chatHistoryRef}>
                        {chatHistory.map((msg, index) => (
                            <div key={index} className={`chat-message ${msg.role}`}>
                                <p>{msg.text}</p>
                            </div>
                        ))}
                        {isChatLoading && (
                            <div className="chat-message model">
                                <div className="typing-indicator"><span></span><span></span><span></span></div>
                            </div>
                        )}
                    </div>
                    <form className="chat-input-form" onSubmit={handleSendMessage}>
                        <input type="text" value={chatInput} onChange={(e) => setChatInput(e.target.value)} placeholder="Ask about your destination..." disabled={isChatLoading} />
                        <button type="submit" disabled={isChatLoading || !chatInput.trim()}>Send</button>
                    </form>
                </div>
            )}
        </>
    );
});


// --- Main App Component ---

const App = () => {
    const [destination, setDestination] = useState('');
    const [duration, setDuration] = useState(7);
    const [budget, setBudget] = useState(80000); // Default budget now in INR
    const [interests, setInterests] = useState<string[]>([]);
    const [plan, setPlan] = useState<any | null>(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [openAccordion, setOpenAccordion] = useState<string | null>(null);
    const [savedTrips, setSavedTrips] = useState<any[]>([]);
    const [showSavedTrips, setShowSavedTrips] = useState(false);
    const [shareText, setShareText] = useState('Share Plan');
    const [isViewOnly, setIsViewOnly] = useState(false);
    const [mapType, setMapType] = useState('m'); // m=map, k=satellite
    const [mapZoom, setMapZoom] = useState(12);
    const [formErrors, setFormErrors] = useState<{ [key: string]: string }>({});

    // Auth State
    const [currentUser, setCurrentUser] = useState<string | null>(null);
    const [currentUserData, setCurrentUserData] = useState<{username: string; profilePic?: string} | null>(null);
    const [showAuthModal, setShowAuthModal] = useState(false);
    const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
    const [authForm, setAuthForm] = useState({ username: '', password: '' });
    const [authError, setAuthError] = useState('');

    // Profile State
    const [showProfileModal, setShowProfileModal] = useState(false);
    const [profilePicInput, setProfilePicInput] = useState('');
    
    // Image Modal State
    const [isImageModalOpen, setIsImageModalOpen] = useState(false);
    const [currentImageInModal, setCurrentImageInModal] = useState('');

    // Chat Assistant State
    const [isChatOpen, setIsChatOpen] = useState(false);
    const [chatHistory, setChatHistory] = useState<{ role: 'user' | 'model'; text: string }[]>([]);
    const [chatInput, setChatInput] = useState('');
    const [isChatLoading, setIsChatLoading] = useState(false);
    const chatRef = useRef<Chat | null>(null);


    // State for Currency Converter
    const [homeCurrency, setHomeCurrency] = useState('USD');
    const [amountToConvert, setAmountToConvert] = useState(100);
    const [convertedAmount, setConvertedAmount] = useState<number | null>(null);
    const [isConverting, setIsConverting] = useState(false);
    const [conversionError, setConversionError] = useState('');

    // State for Flight/Train Status
    const [transportQuery, setTransportQuery] = useState('');
    const [transportStatus, setTransportStatus] = useState<any | null>(null);
    const [isFetchingStatus, setIsFetchingStatus] = useState(false);
    const [statusError, setStatusError] = useState('');
    const [transportTab, setTransportTab] = useState<'train' | 'flight'>('train');

    useEffect(() => {
        // Check for logged-in user session
        const loggedInUser = localStorage.getItem('currentUser');
        if (loggedInUser) {
            setCurrentUser(loggedInUser);
            // Fetch full user data
            const usersData = JSON.parse(localStorage.getItem('travelFoxUsers') || '{"users":[]}');
            const user = usersData.users.find((u: any) => u.username === loggedInUser);
            if (user) {
                setCurrentUserData(user);
            }
        }
        
        // Check for shared plan in URL
        const params = new URLSearchParams(window.location.search);
        const planData = params.get('plan');

        if (planData) {
            try {
                const decodedPlan = JSON.parse(atob(planData));
                setPlan(decodedPlan);
                setDestination(decodedPlan.destination || '');
                setDuration(decodedPlan.itinerary?.length || 7);
                setBudget(decodedPlan.budget || 80000);
                setMapType('m');
                setMapZoom(12);
                resetStatusChecker();
                setOpenAccordion('itinerary');
                setIsViewOnly(true); // Enable view-only mode
                window.history.replaceState({}, document.title, window.location.pathname);
            } catch (e) {
                console.error("Failed to parse plan from URL", e);
                setError("The shared travel plan link appears to be invalid or corrupted.");
                window.history.replaceState({}, document.title, window.location.pathname);
            }
        }
    }, []);
    
    // Effect to load trips when user logs in or out
    useEffect(() => {
        if (currentUser) {
            try {
                const storedTrips = localStorage.getItem(`savedTravelPlans_${currentUser}`);
                setSavedTrips(storedTrips ? JSON.parse(storedTrips) : []);
            } catch (e) {
                console.error("Failed to parse saved trips for user", e);
                setSavedTrips([]); // Reset on error
            }
        } else {
            setSavedTrips([]); // Clear trips if no user is logged in
        }
    }, [currentUser]);
    
    // Effect to reset status checker when tab changes
    useEffect(() => {
        resetStatusChecker();
    }, [transportTab]);

    const saveCurrentTrip = () => {
        if (!currentUser) {
            alert('You must be logged in to save a trip.');
            toggleAuthModal('login');
            return;
        }
        if (!plan || !destination) return;
        
        // Strip image data before saving
        const tripToSave = { ...plan };
        if (tripToSave.itinerary) {
            tripToSave.itinerary = tripToSave.itinerary.map(({ imageUrl, imageLoading, imageError, ...day }) => day);
        }

        const newTrip = { ...tripToSave, id: Date.now(), destination: destination, savedAt: new Date().toISOString() };
        const updatedTrips = [...savedTrips, newTrip];
        setSavedTrips(updatedTrips);
        localStorage.setItem(`savedTravelPlans_${currentUser}`, JSON.stringify(updatedTrips));
        alert('Trip saved successfully!');
    };
    
    const handleSharePlan = () => {
        if (!plan) return;
        try {
            const planWithDestination = { ...plan, destination };
            const jsonString = JSON.stringify(planWithDestination);
            const encodedData = btoa(jsonString);
            const shareableLink = `${window.location.origin}${window.location.pathname}?plan=${encodedData}`;

            navigator.clipboard.writeText(shareableLink).then(() => {
                setShareText('Copied!');
                setTimeout(() => setShareText('Share Plan'), 2000);
            }).catch(err => {
                console.error('Failed to copy link: ', err);
                alert('Failed to copy link.');
            });
        } catch (e) {
            console.error("Failed to create shareable link", e);
            alert("Could not create a shareable link for this plan.");
        }
    };

    const resetStatusChecker = () => {
        setTransportQuery('');
        setTransportStatus(null);
        setIsFetchingStatus(false);
        setStatusError('');
    }

    const loadTrip = (tripToLoad: any) => {
        setPlan(tripToLoad);
        setDestination(tripToLoad.destination);
        setDuration(tripToLoad.itinerary.length);
        setBudget(tripToLoad.budget);
        setMapType('m');
        setMapZoom(12);
        setConvertedAmount(null);
        resetStatusChecker();
        setOpenAccordion('itinerary');
        setShowSavedTrips(false);
        
        // Re-initialize chat for the new destination
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        chatRef.current = ai.chats.create({
          model: 'gemini-2.5-flash',
          config: {
            systemInstruction: `You are a helpful and knowledgeable tourist guide for ${tripToLoad.destination}. Answer the user's questions concisely about the history, culture, food, and attractions of this place.`,
          },
        });
        setChatHistory([]);
        setIsChatOpen(false);
    };

    const deleteTrip = (tripId: number) => {
        if (!currentUser) return;
        if (window.confirm('Are you sure you want to delete this trip?')) {
            const updatedTrips = savedTrips.filter(trip => trip.id !== tripId);
            setSavedTrips(updatedTrips);
            localStorage.setItem(`savedTravelPlans_${currentUser}`, JSON.stringify(updatedTrips));
        }
    };

    const generateTripText = (tripData: any, tripDestination: string) => {
        if (!tripData || !tripDestination) return '';
        let content = `TravelFox - Travel Plan\n=========================\n\n`;
        content += `Destination: ${tripDestination}\n`;
        content += `Duration: ${tripData.itinerary?.length || 'N/A'} days\n`;
        content += `Budget: ₹${tripData.budget} INR\n\n`;

        content += `Daily Itinerary\n-----------------\n`;
        if (tripData.itinerary && tripData.itinerary.length > 0) {
            tripData.itinerary.forEach((day: any) => {
                content += `\nDay ${day.day}:\n`;
                content += `  - Hotel: ${day.hotel}\n`;
                content += `  - Food: ${day.food}\n`;
                content += `  - Attractions: ${day.attractions}\n`;
                content += `  - Transport: ${day.transport}\n`;
                content += `  - Cost: ${day.cost} INR\n`;
            });
        }
        content += `\n\n`;

        content += `Nearby Hotels\n-----------------\n`;
        if (tripData.nearbyHotels && tripData.nearbyHotels.length > 0) {
            tripData.nearbyHotels.forEach((hotel: any) => {
                content += `\n- Name: ${hotel.name}\n  Address: ${hotel.address}\n  Phone: ${hotel.phoneNumber}\n  Website: ${hotel.website}\n`;
            });
        }
        content += `\n\n`;
        
        content += `Safety Alerts\n-----------------\n`;
        content += `Local Scams: ${tripData.safetyAlerts?.scams}\n`;
        content += `Unsafe Areas: ${tripData.safetyAlerts?.unsafeAreas}\n`;
        content += `Emergency Contacts: ${tripData.safetyAlerts?.emergencyContacts}\n\n`;
        
        content += `Live Travel Info\n-----------------\n`;
        content += `Weather: ${tripData.liveInfo?.weather}\n`;
        content += `Traffic: ${tripData.liveInfo?.traffic}\n\n`;

        content += `Personalized Features\n-----------------\n`;
        content += `Best Time to Visit: ${tripData.personalizedFeatures?.bestTimeToVisit}\n`;
        content += `Hidden Gems: ${tripData.personalizedFeatures?.hiddenGems}\n`;
        if (tripData.personalizedFeatures?.travelInsurance) {
            content += `Travel Insurance: ${tripData.personalizedFeatures.travelInsurance}\n`;
        }
        content += `Packing Checklist:\n${tripData.personalizedFeatures?.packingChecklist?.map((item: string) => `  - ${item}`).join('\n')}\n\n`;

        content += `Smart Extras\n-----------------\n`;
        content += `Currency: ${tripData.smartExtras?.currency?.info}\n`;
        content += `Food Safety: ${tripData.smartExtras?.foodSafety}\n`;
        content += `Local Phrases:\n`;
        if (tripData.smartExtras?.language && tripData.smartExtras.language.length > 0) {
            tripData.smartExtras.language.forEach((phrase: any) => {
                content += `  - ${phrase.phrase} (${phrase.pronunciation}): ${phrase.translation}\n`;
            });
        }
        content += `\n\n`;

        content += `Final Checklist\n-----------------\n`;
        content += `${tripData.finalChecklist?.map((item: string) => `- ${item}`).join('\n')}\n`;
        return content;
    };

    const downloadTripAsText = () => {
        const content = generateTripText(plan, destination);
        if (!content) return;
        const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `Travel_Plan_${destination.replace(/\s+/g, '_')}.txt`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };
    
    const handleDownloadSavedTrip = (trip: any) => {
        const content = generateTripText(trip, trip.destination);
        if (!content) { alert("Could not generate text for this trip."); return; };
        const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `Travel_Plan_${trip.destination.replace(/\s+/g, '_')}.txt`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };

    const handleInterestChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { value, checked } = e.target;
        setInterests(prev => checked ? [...prev, value] : prev.filter(interest => interest !== value));
    };

    const toggleAccordion = (id: string) => {
        setOpenAccordion(openAccordion === id ? null : id);
    };
    
    const handleCurrencyConversion = async () => {
        if (!plan?.smartExtras?.currency?.localCode || !homeCurrency || amountToConvert <= 0) {
            setConversionError("Please enter a valid amount and currency code.");
            return;
        }
        setIsConverting(true);
        setConversionError('');
        setConvertedAmount(null);
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const prompt = `What is the current exchange rate for 1 ${homeCurrency.toUpperCase()} to ${plan.smartExtras.currency.localCode}? Please provide only the numeric conversion factor.`;
            const response = await ai.models.generateContent({ model: "gemini-2.5-flash", contents: prompt });
            const rateText = response.text.trim();
            const rate = parseFloat(rateText.replace(/,/g, ''));
            if (isNaN(rate)) { throw new Error("Could not parse the exchange rate from the response."); }
            setConvertedAmount(amountToConvert * rate);
        } catch (err) {
            console.error("Currency conversion failed:", err);
            setConversionError("Could not fetch the exchange rate. Please try again.");
        } finally {
            setIsConverting(false);
        }
    };

    const handleTransportStatusCheck = async () => {
        if (!transportQuery) { setStatusError(`Please enter a ${transportTab} number.`); return; }
        setIsFetchingStatus(true);
        setStatusError('');
        setTransportStatus(null);
    
        let promptContext = '';
        if (transportTab === 'train') {
            promptContext = `Provide the real-time status for the TRAIN with number: "${transportQuery}". The destination context is "${destination}". You must use this context to identify the correct railway network (e.g., Indian Railways for India). For example, if the destination is "Mumbai, India" and query is "12951", you should look for "Indian Railways 12951".`;
        } else { // flight
            promptContext = `Provide the real-time status for the FLIGHT with number or route: "${transportQuery}". The destination context is "${destination}".`;
        }
    
        const prompt = `${promptContext} Provide accurate details including the identifier (flight/train number), the official name of the train or flight (e.g., "Pune - Manmad Express"), its current status (e.g., On Time, Delayed), scheduled and estimated departure/arrival times, and location info (current station, gate, platform). If no reliable information can be found, set 'found' to false.`;

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const responseSchema = {
                type: Type.OBJECT,
                properties: {
                    id: { type: Type.STRING, description: 'Flight or train number (e.g., UA123).' },
                    name: { type: Type.STRING, description: 'The official name of the train or flight route (e.g., "Pune - Manmad Express").' },
                    type: { type: Type.STRING, description: 'Type of transport (e.g., Flight, Train).' },
                    status: { type: Type.STRING, description: 'Current status (e.g., On Time, Delayed, Canceled, Boarding, Landed).' },
                    scheduledDeparture: { type: Type.STRING, description: 'Scheduled departure time.' },
                    estimatedDeparture: { type: Type.STRING, description: 'Estimated or actual departure time.' },
                    scheduledArrival: { type: Type.STRING, description: 'Scheduled arrival time.' },
                    estimatedArrival: { type: Type.STRING, description: 'Estimated or actual arrival time.' },
                    locationInfo: { type: Type.STRING, description: 'Gate, terminal, platform or current location information.' },
                    found: { type: Type.BOOLEAN, description: 'Set to false if no information could be found.'}
                },
            };
            const response = await ai.models.generateContent({ model: "gemini-2.5-flash", contents: prompt, config: { responseMimeType: "application/json", responseSchema } });
            const statusData = JSON.parse(response.text);
            if (statusData.found === false) { setStatusError(`Could not find status for "${transportQuery}". Please check the number and try again.`); } else { setTransportStatus(statusData); }
        } catch (err) {
            console.error("Transport status check failed:", err);
            setStatusError(`Could not fetch status for "${transportQuery}". Please try again.`);
        } finally {
            setIsFetchingStatus(false);
        }
    };
    
    const generateImagesForPlan = async (currentPlan: any) => {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

        for (const day of currentPlan.itinerary) {
            try {
                const response = await ai.models.generateImages({
                    model: 'imagen-4.0-generate-001',
                    prompt: `A beautiful, realistic, high-quality photograph of ${day.attractions} in ${destination}. No text or watermarks.`,
                    config: { numberOfImages: 1, outputMimeType: 'image/jpeg', aspectRatio: '4:3' },
                });
                
                const base64ImageBytes = response.generatedImages[0].image.imageBytes;
                const imageUrl = `data:image/jpeg;base64,${base64ImageBytes}`;
                
                setPlan((prevPlan: any) => {
                    if (!prevPlan) return null;
                    const newItinerary = prevPlan.itinerary.map((d: any) => 
                        d.day === day.day ? { ...d, imageUrl, imageLoading: false } : d
                    );
                    return { ...prevPlan, itinerary: newItinerary };
                });

            } catch (err) {
                console.error(`Failed to generate image for Day ${day.day}:`, err);
                setPlan((prevPlan: any) => {
                    if (!prevPlan) return null;
                    const newItinerary = prevPlan.itinerary.map((d: any) => 
                        d.day === day.day ? { ...d, imageError: true, imageLoading: false } : d
                    );
                    return { ...prevPlan, itinerary: newItinerary };
                });
            }
        }
    };

    const generatePlan = async () => {
        setLoading(true);
        setError('');
        setPlan(null);
        setMapType('m');
        setMapZoom(12);
        setConvertedAmount(null);
        resetStatusChecker();
        setOpenAccordion('itinerary');
        setIsChatOpen(false);
        setChatHistory([]);
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const prompt = `
                Create a detailed travel plan with the following specifications:
                - Destination: ${destination}
                - Duration: ${duration} days
                - Budget: Approximately ${budget} INR
                - Interests: ${interests.join(', ')}

                Provide a comprehensive plan covering all the sections defined in the JSON schema. Be creative and helpful.
                All monetary values, including daily costs and hotel costs, should be provided in INR.
                For each attraction in the daily itinerary, also provide a concise and effective YouTube search query that would find a good video tour or guide for that specific location (e.g., for "Eiffel Tower", the query could be "Eiffel Tower Paris tour guide").
                For nearby hotels, find a few recommendations and include their name, phone number, website, and full physical address.
                For the currency, identify the local currency's name and its official 3-letter code.
                For the language phrases, provide an array of common phrases, each with its English translation and a simple, phonetic pronunciation guide.
                Provide a tailored travel insurance recommendation based on the destination and duration, with a brief justification.
            `;
            const responseSchema = {
                type: Type.OBJECT,
                properties: {
                    itinerary: {
                        type: Type.ARRAY, description: 'Day-wise travel itinerary.',
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                day: { type: Type.NUMBER, description: 'Day number' },
                                hotel: { type: Type.STRING, description: 'Hotel suggestion with approx. cost.' },
                                food: { type: Type.STRING, description: 'Food and local cuisine recommendations.' },
                                attractions: { type: Type.STRING, description: 'Attractions and sightseeing spots.' },
                                youtubeSearchQuery: { type: Type.STRING, description: 'A concise YouTube search query for a tour or guide of the main attraction.'},
                                transport: { type: Type.STRING, description: 'Transportation options.' },
                                cost: { type: Type.STRING, description: 'Approximate daily cost in INR.' },
                            },
                        },
                    },
                    nearbyHotels: {
                        type: Type.ARRAY, description: 'A list of recommended hotels near the destination with their contact details.',
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                name: { type: Type.STRING, description: 'Name of the hotel.' },
                                phoneNumber: { type: Type.STRING, description: 'Contact phone number of the hotel.' },
                                website: { type: Type.STRING, description: 'Official website URL of the hotel.' },
                                address: { type: Type.STRING, description: 'Full physical address for mapping.' },
                            },
                        },
                    },
                    liveInfo: { type: Type.OBJECT, properties: { weather: { type: Type.STRING, description: 'Real-time weather forecast.' }, traffic: { type: Type.STRING, description: 'Traffic alerts and best routes.' }, } },
                    safetyAlerts: { type: Type.OBJECT, properties: { scams: { type: Type.STRING, description: 'Common local scams to be aware of.' }, unsafeAreas: { type: Type.STRING, description: 'Areas to avoid, especially at night.' }, emergencyContacts: { type: Type.STRING, description: 'Essential local emergency numbers (police, hospital, embassy).' }, } },
                    personalizedFeatures: { type: Type.OBJECT, properties: { bestTimeToVisit: { type: Type.STRING, description: 'Recommendations on the best time to visit attractions.' }, hiddenGems: { type: Type.STRING, description: 'Offbeat or less-known places to explore.' }, packingChecklist: { type: Type.ARRAY, items: { type: Type.STRING }, description: 'A packing checklist based on destination and weather.' }, travelInsurance: { type: Type.STRING, description: 'A tailored travel insurance recommendation and justification.' } } },
                    smartExtras: {
                        type: Type.OBJECT,
                        properties: {
                            currency: { type: Type.OBJECT, properties: { info: { type: Type.STRING, description: 'General currency information and conversion tips.' }, localCode: { type: Type.STRING, description: 'The official 3-letter currency code for the destination (e.g., JPY, EUR).' }, localName: { type: Type.STRING, description: 'The name of the local currency (e.g., Japanese Yen, Euro).' } } },
                            language: {
                                type: Type.ARRAY, description: 'Common local phrases with translation and phonetic pronunciation.',
                                items: {
                                    type: Type.OBJECT,
                                    properties: {
                                        phrase: { type: Type.STRING, description: 'The phrase in the local language.' },
                                        translation: { type: Type.STRING, description: 'The English translation of the phrase.' },
                                        pronunciation: { type: Type.STRING, description: 'A simple, phonetic guide to pronouncing the phrase.' }
                                    }
                                }
                            },
                            foodSafety: { type: Type.STRING, description: 'Food safety advice, including vegetarian/allergy info.' },
                        },
                    },
                    finalChecklist: { type: Type.ARRAY, items: { type: Type.STRING }, description: 'A final safety and travel checklist summary.' }
                },
            };
            const response = await ai.models.generateContent({ model: "gemini-2.5-flash", contents: prompt, config: { responseMimeType: "application/json", responseSchema } });
            const parsedPlan = JSON.parse(response.text);
            
            // Initialize itinerary with image loading states
            const planWithImageState = {
                ...parsedPlan,
                budget: budget,
                itinerary: parsedPlan.itinerary.map((day: any) => ({
                    ...day,
                    imageUrl: null,
                    imageLoading: true,
                    imageError: false,
                })),
            };
            setPlan(planWithImageState);

            // Initialize chat
            chatRef.current = ai.chats.create({
              model: 'gemini-2.5-flash',
              config: {
                systemInstruction: `You are a helpful and knowledgeable tourist guide for ${destination}. Answer the user's questions concisely about the history, culture, food, and attractions of this place.`,
              },
            });
            
            // Start generating images asynchronously
            generateImagesForPlan(planWithImageState);
            
        } catch (err) {
            console.error(err);
            setError('Failed to generate travel plan. Please check your inputs or try again later.');
        } finally {
            setLoading(false);
        }
    };
    
    // Auth Functions
    const handleAuthChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setAuthForm(prev => ({ ...prev, [name]: value }));
    };

    const handleSignup = () => {
        if (!authForm.username || !authForm.password) { setAuthError('Username and password are required.'); return; }
        const usersData = JSON.parse(localStorage.getItem('travelFoxUsers') || '{"users":[]}');
        const userExists = usersData.users.find((u: any) => u.username === authForm.username);
        if (userExists) { setAuthError('Username already exists.'); return; }
        
        const newUser = { ...authForm, profilePic: '' };
        usersData.users.push(newUser);
        localStorage.setItem('travelFoxUsers', JSON.stringify(usersData));
        
        setCurrentUser(authForm.username);
        setCurrentUserData(newUser);
        localStorage.setItem('currentUser', authForm.username);

        setShowAuthModal(false);
        setAuthForm({ username: '', password: '' });
        setAuthError('');
    };

    const handleLogin = () => {
        if (!authForm.username || !authForm.password) { setAuthError('Username and password are required.'); return; }
        const usersData = JSON.parse(localStorage.getItem('travelFoxUsers') || '{"users":[]}');
        const user = usersData.users.find((u: any) => u.username === authForm.username && u.password === authForm.password);
        if (user) {
            setCurrentUser(user.username);
            setCurrentUserData(user);
            localStorage.setItem('currentUser', user.username);
            setShowAuthModal(false);
            setAuthForm({ username: '', password: '' });
            setAuthError('');
        } else {
            setAuthError('Invalid username or password.');
        }
    };
    
    const handleClearPlan = () => {
        // Reset all plan and form state to default
        setPlan(null);
        setError('');
        setDestination('');
        setDuration(7);
        setBudget(80000);
        setInterests([]);
        setOpenAccordion(null);
        setIsViewOnly(false);
        setFormErrors({});
        
        // Reset map state
        setMapType('m');
        setMapZoom(12);

        // Reset feature states
        setConvertedAmount(null);
        setConversionError('');
        resetStatusChecker();
        
        // Reset chat
        setIsChatOpen(false);
        setChatHistory([]);
        chatRef.current = null;
    };

    const handleLogout = () => {
        // Clear user session
        setCurrentUser(null);
        setCurrentUserData(null);
        localStorage.removeItem('currentUser');

        // Reset all plan and form state to default
        handleClearPlan();
    };

    const toggleAuthModal = (mode: 'login' | 'signup') => {
        setAuthMode(mode);
        setShowAuthModal(true);
        setAuthError('');
        setAuthForm({ username: '', password: '' });
    };

    // Profile Functions
    const toggleProfileModal = () => {
        if (currentUserData) {
            setProfilePicInput(currentUserData.profilePic || '');
            setShowProfileModal(true);
        }
    };

    const handleProfileSave = () => {
        if (!currentUser) return;
        const usersData = JSON.parse(localStorage.getItem('travelFoxUsers') || '{"users":[]}');
        const userIndex = usersData.users.findIndex((u: any) => u.username === currentUser);

        if (userIndex > -1) {
            usersData.users[userIndex].profilePic = profilePicInput;
            localStorage.setItem('travelFoxUsers', JSON.stringify(usersData));
            setCurrentUserData(usersData.users[userIndex]);
            setShowProfileModal(false);
        } else {
            alert("Could not update profile. Please try logging in again.");
        }
    };
    
    // Chat Functions
    const handleSendMessage = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!chatInput.trim() || !chatRef.current || isChatLoading) return;

        const userMessage = { role: 'user' as const, text: chatInput };
        setChatHistory(prev => [...prev, userMessage]);
        setChatInput('');
        setIsChatLoading(true);

        try {
            const response = await chatRef.current.sendMessage({ message: userMessage.text });
            const modelMessage = { role: 'model' as const, text: response.text };
            setChatHistory(prev => [...prev, modelMessage]);
        } catch (err) {
            console.error("Chat error:", err);
            const errorMessage = { role: 'model' as const, text: "Sorry, I couldn't get a response. Please try again." };
            setChatHistory(prev => [...prev, errorMessage]);
        } finally {
            setIsChatLoading(false);
        }
    };
    
    // Form Validation Handlers
    const handleDestinationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        setDestination(value);
        if (!value.trim()) {
            setFormErrors(prev => ({ ...prev, destination: 'Destination is required.' }));
        } else {
            setFormErrors(prev => {
                const newErrors = { ...prev };
                delete newErrors.destination;
                return newErrors;
            });
        }
    };

    const handleDurationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        const numValue = parseInt(value);
        setDuration(numValue || 0);

        if (!value || numValue < 1) {
            setFormErrors(prev => ({ ...prev, duration: 'Duration must be a positive number.' }));
        } else {
            setFormErrors(prev => {
                const newErrors = { ...prev };
                delete newErrors.duration;
                return newErrors;
            });
        }
    };

    const handleBudgetChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        const numValue = parseInt(value);
        setBudget(numValue || 0);

        if (value.trim() === '' || numValue < 0) { // Also check for empty string
            setFormErrors(prev => ({ ...prev, budget: 'Budget must be a non-negative number.' }));
        } else {
            setFormErrors(prev => {
                const newErrors = { ...prev };
                delete newErrors.budget;
                return newErrors;
            });
        }
    };

    const renderPlan = () => {
        if (!plan) return null;
        return (
            <>
                <div className="results-header">
                     <div>
                        <h2>Your Trip to {destination}</h2>
                        <div className="budget-display"><p>Total Budget: <strong>₹{plan.budget.toLocaleString('en-IN')}</strong></p></div>
                     </div>
                     <div className="header-actions">
                         <button onClick={handleSharePlan} className="btn-share">{shareText}</button>
                         <button onClick={saveCurrentTrip} className="btn-save">Save Trip</button>
                         <button onClick={downloadTripAsText} className="btn-download">Download Plan</button>
                         <button onClick={handleClearPlan} className="btn-clear">Clear Plan</button>
                     </div>
                </div>
                <AccordionItem id="itinerary" title="Daily Itinerary" openAccordion={openAccordion} toggleAccordion={toggleAccordion}>
                    <div style={{ overflowX: 'auto' }}>
                        <table className="itinerary-table">
                            <thead><tr><th>Day</th><th>Hotel</th><th>Food</th><th>Attractions</th><th>Transport</th><th>Cost (INR)</th></tr></thead>
                            <tbody>
                                {plan.itinerary?.map((item: any) => (
                                    <tr key={item.day}>
                                        <td>{item.day}</td>
                                        <td>{item.hotel}</td>
                                        <td>{item.food}</td>
                                        <td className="attraction-cell">
                                            {item.attractions}
                                            {item.youtubeSearchQuery && (
                                                <a href={`https://www.youtube.com/results?search_query=${encodeURIComponent(item.youtubeSearchQuery)}`} target="_blank" rel="noopener noreferrer" className="youtube-link">Watch on YouTube</a>
                                            )}
                                            <div className="attraction-image-container">
                                                {item.imageLoading && <div className="loader tiny-loader"></div>}
                                                {item.imageError && <p className="image-error">Image failed</p>}
                                                {item.imageUrl && (
                                                    <img src={item.imageUrl} alt={`View of ${item.attractions}`} className="attraction-thumbnail" onClick={() => { setCurrentImageInModal(item.imageUrl); setIsImageModalOpen(true); }}/>
                                                )}
                                            </div>
                                        </td>
                                        <td>{item.transport}</td>
                                        <td>{item.cost}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </AccordionItem>
                <AccordionItem id="map" title="Destination Map" openAccordion={openAccordion} toggleAccordion={toggleAccordion}>
                    <div className="map-controls">
                        <div className="map-type-selector">
                            <button onClick={() => setMapType('m')} className={mapType === 'm' ? 'active' : ''}>Map</button>
                            <button onClick={() => setMapType('k')} className={mapType === 'k' ? 'active' : ''}>Satellite</button>
                        </div>
                        <div className="map-zoom-controls">
                            <button onClick={() => setMapZoom(prev => Math.min(prev + 1, 21))} disabled={mapZoom >= 21}>+</button>
                            <span>Zoom: {mapZoom}</span>
                            <button onClick={() => setMapZoom(prev => Math.max(prev - 1, 1))} disabled={mapZoom <= 1}>-</button>
                        </div>
                    </div>
                    <div className="map-container">
                        <iframe
                            key={`${destination}-${mapType}-${mapZoom}`}
                            title="Destination Map" 
                            src={`https://maps.google.com/maps?q=${encodeURIComponent(destination)}&t=${mapType}&z=${mapZoom}&output=embed`}
                            width="100%" height="450" 
                            style={{ border: 0, borderRadius: 'var(--border-radius)' }} 
                            allowFullScreen={false} 
                            loading="lazy" 
                            referrerPolicy="no-referrer-when-downgrade">
                        </iframe>
                    </div>
                </AccordionItem>
                <AccordionItem id="hotels" title="Nearby Hotels" openAccordion={openAccordion} toggleAccordion={toggleAccordion}>
                    <div className="hotel-list">
                        {plan.nearbyHotels && plan.nearbyHotels.length > 0 ? (
                            plan.nearbyHotels.map((hotel: any, index: number) => (
                                <div key={index} className="hotel-card">
                                    <h4>{hotel.name}</h4>
                                    {hotel.address && <p><strong>Address:</strong> <a href={`https://maps.google.com/maps?q=${encodeURIComponent(hotel.address)}`} target="_blank" rel="noopener noreferrer">{hotel.address}</a></p>}
                                    {hotel.phoneNumber && <p><strong>Phone:</strong> <a href={`tel:${hotel.phoneNumber}`}>{hotel.phoneNumber}</a></p>}
                                    {hotel.website && <p><strong>Website:</strong> <a href={hotel.website} target="_blank" rel="noopener noreferrer">{hotel.website}</a></p>}
                                </div>
                            ))
                        ) : (<p>No specific hotel recommendations found.</p>)}
                    </div>
                </AccordionItem>
                <AccordionItem id="safety" title="Safety Alerts" openAccordion={openAccordion} toggleAccordion={toggleAccordion}>
                    <h3>Local Scams</h3><p>{plan.safetyAlerts?.scams}</p>
                    <h3>Unsafe Areas</h3><p>{plan.safetyAlerts?.unsafeAreas}</p>
                    <h3>Emergency Contacts</h3><p>{plan.safetyAlerts?.emergencyContacts}</p>
                </AccordionItem>
                 <AccordionItem id="liveInfo" title="Live Travel Info" openAccordion={openAccordion} toggleAccordion={toggleAccordion}>
                    <h3>Weather Forecast</h3><p>{plan.liveInfo?.weather}</p>
                    <h3>Traffic & Routes</h3><p>{plan.liveInfo?.traffic}</p>
                    <div className="transport-status-checker">
                        <div className="transport-tabs">
                            <button className={`transport-tab-btn ${transportTab === 'train' ? 'active' : ''}`} onClick={() => setTransportTab('train')}>
                                Train Status
                            </button>
                            <button className={`transport-tab-btn ${transportTab === 'flight' ? 'active' : ''}`} onClick={() => setTransportTab('flight')}>
                                Flight Status
                            </button>
                        </div>
                        <div className="status-input-group">
                            <input type="text" value={transportQuery} onChange={(e) => setTransportQuery(e.target.value)} placeholder={transportTab === 'train' ? "e.g., 12951" : "e.g., AI 101"} />
                            <button onClick={handleTransportStatusCheck} disabled={isFetchingStatus}>{isFetchingStatus ? 'Checking...' : 'Check Status'}</button>
                        </div>
                        {isFetchingStatus && <div className="loader small-loader"></div>}
                        {statusError && <div className="error-message small-error">{statusError}</div>}
                        {transportStatus && (
                            <div className="status-result">
                                <div className="status-result-header">
                                    <div><h4>{transportStatus.type}: {transportStatus.id}</h4>{transportStatus.name && <p className="transport-name">{transportStatus.name}</p>}</div>
                                    <span className={`status-badge status-${transportStatus.status?.toLowerCase().replace(/\s+/g, '-')}`}>{transportStatus.status}</span>
                                </div>
                                <div className="status-grid">
                                    <div><strong>Departure:</strong> {transportStatus.scheduledDeparture}</div>
                                    <div><strong>Arrival:</strong> {transportStatus.scheduledArrival}</div>
                                    <div><strong>Est. Departure:</strong> {transportStatus.estimatedDeparture || 'N/A'}</div>
                                    <div><strong>Est. Arrival:</strong> {transportStatus.estimatedArrival || 'N/A'}</div>
                                </div>
                                <div className="status-location"><strong>Location:</strong> {transportStatus.locationInfo || 'N/A'}</div>
                            </div>
                        )}
                    </div>
                </AccordionItem>
                 <AccordionItem id="personalized" title="Personalized Features" openAccordion={openAccordion} toggleAccordion={toggleAccordion}>
                    <h3>Best Time to Visit</h3><p>{plan.personalizedFeatures?.bestTimeToVisit}</p>
                    <h3>Hidden Gems</h3><p>{plan.personalizedFeatures?.hiddenGems}</p>
                    {plan.personalizedFeatures?.travelInsurance && (
                        <>
                            <h3>Travel Insurance Recommendation</h3>
                            <p>{plan.personalizedFeatures.travelInsurance}</p>
                        </>
                    )}
                    <h3>Packing Checklist</h3>
                    <ul>{plan.personalizedFeatures?.packingChecklist?.map((item: string, i: number) => <li key={i}>{item}</li>)}</ul>
                </AccordionItem>
                 <AccordionItem id="extras" title="Smart Extras" openAccordion={openAccordion} toggleAccordion={toggleAccordion}>
                    <h3>Currency Info</h3><p>{plan.smartExtras?.currency?.info}</p>
                    <h3>Currency Converter</h3>
                    {plan.smartExtras?.currency?.localCode ? (
                        <div className="currency-converter">
                            <div className="converter-inputs">
                                <div className="form-group"><label htmlFor="amount">Amount</label><input type="number" id="amount" value={amountToConvert} onChange={(e) => setAmountToConvert(parseFloat(e.target.value))} /></div>
                                <div className="form-group"><label htmlFor="homeCurrency">Your Currency</label><input type="text" id="homeCurrency" value={homeCurrency} onChange={(e) => setHomeCurrency(e.target.value.toUpperCase())} maxLength={3} placeholder="e.g., USD" /></div>
                            </div>
                            <button onClick={handleCurrencyConversion} disabled={isConverting} className="btn-convert">{isConverting ? 'Converting...' : `Convert to ${plan.smartExtras.currency.localCode}`}</button>
                            {convertedAmount !== null && (<div className="conversion-result"><p>{amountToConvert} {homeCurrency} is approximately</p><h4>{convertedAmount.toFixed(2)} {plan.smartExtras.currency.localCode}</h4></div>)}
                            {conversionError && <div className="error-message small-error">{conversionError}</div>}
                        </div>
                    ) : <p>Currency information not available.</p>}
                    <h3>Local Phrases</h3>
                    <div className="phrase-list">
                        {plan.smartExtras?.language?.map((item: any, i: number) => (
                            <div key={i} className="phrase-item"><p className="phrase-local">{item.phrase}</p><p className="phrase-pronunciation">{item.pronunciation}</p><p className="phrase-translation">{item.translation}</p></div>
                        ))}
                    </div>
                    <h3>Food Safety</h3><p>{plan.smartExtras?.foodSafety}</p>
                </AccordionItem>
                 <AccordionItem id="final" title="Final Safety & Travel Checklist" openAccordion={openAccordion} toggleAccordion={toggleAccordion}>
                    <ul>{plan.finalChecklist?.map((item: string, i: number) => <li key={i}>{item}</li>)}</ul>
                </AccordionItem>
            </>
        );
    };

    return (
        <>
            {showSavedTrips && <SavedTripsModal savedTrips={savedTrips} loadTrip={loadTrip} handleDownloadSavedTrip={handleDownloadSavedTrip} deleteTrip={deleteTrip} setShowSavedTrips={setShowSavedTrips} />}
            {showAuthModal && <AuthModal authMode={authMode} setShowAuthModal={setShowAuthModal} authForm={authForm} handleAuthChange={handleAuthChange} authError={authError} handleLogin={handleLogin} handleSignup={handleSignup} />}
            {showProfileModal && <ProfileModal setShowProfileModal={setShowProfileModal} currentUserData={currentUserData} profilePicInput={profilePicInput} setProfilePicInput={setProfilePicInput} handleProfileSave={handleProfileSave} />}
            {isImageModalOpen && <ImageModal currentImageInModal={currentImageInModal} setIsImageModalOpen={setIsImageModalOpen} />}
            
            <div className="container">
                 <header>
                    <div className="logo-container">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" role="img" aria-label="TravelFox logo"><path d="M21.52,11.23,13.76,2.2a2.38,2.38,0,0,0-3.52,0L2.48,11.23a2.39,2.39,0,0,0,0,3.53l5,6A2.39,2.39,0,0,0,9.24,22H14.76a2.39,2.39,0,0,0,1.76-.74l5-6A2.39,2.39,0,0,0,21.52,11.23Z" /></svg>
                        <h1>TravelFox</h1>
                    </div>
                    <div className="header-auth">
                        {currentUser ? (
                            <>
                                {currentUserData?.profilePic && <img src={currentUserData.profilePic} alt="Profile" className="header-profile-pic"/>}
                                <span className="welcome-message">Welcome, {currentUser}!</span>
                                <button onClick={toggleProfileModal} className="btn-auth btn-profile">Profile</button>
                                <button onClick={handleLogout} className="btn-auth">Logout</button>
                            </>
                        ) : (
                            <>
                                <button onClick={() => toggleAuthModal('login')} className="btn-auth">Login</button>
                                <button onClick={() => toggleAuthModal('signup')} className="btn-auth btn-signup">Sign Up</button>
                            </>
                        )}
                    </div>
                </header>
                <p className="tagline">Your personalized and safe journey starts here.</p>
                <main className="main-content">
                    <div className="form-container">
                        <h2>Plan Your Trip</h2>
                        <div className="form-group">
                            <label htmlFor="destination">Destination</label>
                            <input type="text" id="destination" value={destination} onChange={handleDestinationChange} placeholder="e.g., Paris, France" disabled={isViewOnly} className={formErrors.destination ? 'input-error' : ''} />
                            {formErrors.destination && <p className="validation-error">{formErrors.destination}</p>}
                        </div>
                        <div className="form-group">
                            <label htmlFor="duration">Duration (days)</label>
                            <input type="number" id="duration" value={duration || ''} onChange={handleDurationChange} min="1" disabled={isViewOnly} className={formErrors.duration ? 'input-error' : ''} />
                            {formErrors.duration && <p className="validation-error">{formErrors.duration}</p>}
                        </div>
                        <div className="form-group">
                            <label htmlFor="budget">Budget (INR)</label>
                            <input type="number" id="budget" value={budget || ''} onChange={handleBudgetChange} min="0" disabled={isViewOnly} className={formErrors.budget ? 'input-error' : ''} />
                            {formErrors.budget && <p className="validation-error">{formErrors.budget}</p>}
                        </div>
                        <div className="form-group">
                            <label>Interests</label>
                            <div className="interests-group">
                                {['Adventure', 'Culture', 'Food', 'Shopping', 'Relaxation', 'History'].map(interest => (
                                    <div key={interest} className="interest-item">
                                        <input type="checkbox" id={interest} value={interest} checked={interests.includes(interest)} onChange={handleInterestChange} disabled={isViewOnly}/><label htmlFor={interest}>{interest}</label>
                                    </div>
                                ))}
                            </div>
                        </div>
                        <button onClick={generatePlan} disabled={loading || isViewOnly || Object.keys(formErrors).length > 0 || !destination || duration < 1}>{loading ? 'Generating...' : 'Plan My Trip'}</button>
                         <button onClick={() => setShowSavedTrips(true)} disabled={!currentUser || isViewOnly} className="btn-secondary">Load Saved Trips</button>
                    </div>
                    <div className="results-container">
                        {loading && <div className="results-placeholder"><div className="loader"></div><p>Planning your amazing trip...</p></div>}
                        {error && <div className="error-message">{error}</div>}
                        {!loading && !error && !plan && <div className="results-placeholder"><p>Your personalized travel plan will appear here.</p></div>}
                        {plan && renderPlan()}
                    </div>
                </main>
            </div>
            {plan && !loading && <ChatAssistant isChatOpen={isChatOpen} setIsChatOpen={setIsChatOpen} chatHistory={chatHistory} isChatLoading={isChatLoading} chatInput={chatInput} setChatInput={setChatInput} handleSendMessage={handleSendMessage} />}
        </>
    );
};

const container = document.getElementById('root');
const root = createRoot(container!);
root.render(<App />);